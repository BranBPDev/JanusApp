import numpy as np


def _edge_keys(F: np.ndarray):
    """(aristas ordenadas (3m, 2), clave única de cada una) de una malla de triángulos."""
    e = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]])
    e.sort(axis=1)
    return e, e[:, 0].astype(np.int64) * (int(e.max()) + 1) + e[:, 1]


def unique_edges(F: np.ndarray) -> np.ndarray:
    e, key = _edge_keys(F)
    _, idx = np.unique(key, return_index=True)
    return e[idx]


def compact(V: np.ndarray, F: np.ndarray):
    used = np.unique(F)
    remap = np.full(len(V), -1, np.int64)
    remap[used] = np.arange(len(used))
    return V[used], remap[F].astype(np.int32)


def remove_small_components(V, F, min_ratio: float = 0.02):
    """Elimina islas sueltas (menos del 2 % de las caras de la mayor)."""
    n = len(V)
    labels = np.arange(n)
    while True:
        fl = labels[F].min(axis=1)
        new = labels.copy()
        for k in range(3):
            np.minimum.at(new, F[:, k], fl)
        new = new[new]
        if np.array_equal(new, labels):
            break
        labels = new
    face_label = labels[F[:, 0]]
    ids, counts = np.unique(face_label, return_counts=True)
    keep = ids[counts >= counts.max() * min_ratio]
    return compact(V, F[np.isin(face_label, keep)])


def taubin_smooth(V: np.ndarray, F: np.ndarray, iters: int, lam: float = 0.5, mu: float = -0.53) -> np.ndarray:
    """Suavizado que no encoge el volumen."""
    if iters <= 0:
        return V
    n = len(V)
    e = unique_edges(F)
    a = np.concatenate([e[:, 0], e[:, 1]])
    b = np.concatenate([e[:, 1], e[:, 0]])
    deg = np.maximum(np.bincount(a, minlength=n), 1).astype(np.float64)
    V = V.astype(np.float64).copy()

    def laplacian(P):
        out = np.empty_like(P)
        for ax in range(3):
            out[:, ax] = np.bincount(a, weights=P[b, ax], minlength=n) / deg - P[:, ax]
        return out

    for _ in range(iters):
        V += lam * laplacian(V)
        V += mu * laplacian(V)
    return V


def is_watertight(F: np.ndarray) -> bool:
    return bool((np.unique(_edge_keys(F)[1], return_counts=True)[1] == 2).all())


def crease_normals(V: np.ndarray, F: np.ndarray, angle_deg: float = 40.0) -> np.ndarray:
    """Normales por esquina de cara (m,3,3): suaves entre caras casi coplanares y duras en las aristas marcadas."""
    fn = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    area = np.linalg.norm(fn, axis=1)
    unit = fn / np.maximum(area, 1e-30)[:, None]
    adj = [[] for _ in range(len(V))]
    for fi, tri in enumerate(F.tolist()):
        for v in tri:
            adj[v].append(fi)
    cos_t = np.cos(np.radians(angle_deg))
    out = np.zeros((len(F), 3, 3))
    for fi, tri in enumerate(F.tolist()):
        for k, v in enumerate(tri):
            nb = np.array(adj[v])
            near = nb[(unit[nb] @ unit[fi]) >= cos_t]
            n = (fn[near]).sum(axis=0)
            length = np.linalg.norm(n)
            out[fi, k] = n / length if length > 1e-30 else unit[fi]
    return out


def build_attributes(V, F, corner_normals, corner_uvs=None):
    """Convierte atributos por esquina en vértices únicos (duplica donde cambian normal o UV)."""
    m = len(F)
    cols = [F.reshape(-1, 1).astype(np.float64), np.round(corner_normals.reshape(-1, 3), 4)]
    if corner_uvs is not None:
        cols.append(np.round(corner_uvs.reshape(-1, 2), 5))
    keys = np.concatenate(cols, axis=1)
    uniq, first, inverse = np.unique(keys, axis=0, return_index=True, return_inverse=True)
    corner = np.arange(m * 3)[first]
    verts = V[F.reshape(-1)[corner]]
    normals = corner_normals.reshape(-1, 3)[corner]
    uvs = corner_uvs.reshape(-1, 2)[corner] if corner_uvs is not None else None
    return verts, inverse.reshape(m, 3).astype(np.int32), normals, uvs
